/*
  # Water Wastage Data Schema

  1. New Tables
    - `historical_data`
      - Records historical water wastage measurements
      - Includes environmental factors and wastage metrics
    - `geographical_areas`
      - Stores information about different geographical locations
      - Contains terrain and climate characteristics
    - `structure_types`
      - Catalogs different water retention structure types
      - Includes effectiveness ratings and suitable conditions

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Geographical Areas Table
CREATE TABLE geographical_areas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  terrain_type text NOT NULL,
  elevation numeric NOT NULL,
  soil_type text NOT NULL,
  climate_zone text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE geographical_areas ENABLE ROW LEVEL SECURITY;

-- Structure Types Table
CREATE TABLE structure_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  min_capacity numeric NOT NULL,
  max_capacity numeric NOT NULL,
  suitable_terrain text[] NOT NULL,
  suitable_climate text[] NOT NULL,
  efficiency_rating numeric NOT NULL,
  maintenance_requirement text NOT NULL,
  model_url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE structure_types ENABLE ROW LEVEL SECURITY;

-- Historical Data Table
CREATE TABLE historical_data (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  geographical_area_id uuid REFERENCES geographical_areas(id),
  date date NOT NULL,
  temperature numeric NOT NULL,
  rainfall numeric NOT NULL,
  retention_capacity numeric NOT NULL,
  water_wastage numeric NOT NULL,
  evaporation_rate numeric NOT NULL,
  seepage_rate numeric NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE historical_data ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Allow read access to all authenticated users"
  ON geographical_areas
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow read access to all authenticated users"
  ON structure_types
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow read access to all authenticated users"
  ON historical_data
  FOR SELECT
  TO authenticated
  USING (true);
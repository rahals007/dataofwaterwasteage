import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import type { HistoricalData } from '../../types/database';

interface Props {
  data: HistoricalData[];
}

export default function WastageChart({ data }: Props) {
  const chartData = data.map(item => ({
    date: new Date(item.date).toLocaleDateString(),
    wastage: item.water_wastage,
    evaporation: item.evaporation_rate,
    seepage: item.seepage_rate
  }));

  return (
    <div className="bg-white p-4 rounded-lg shadow-lg">
      <h3 className="text-xl font-semibold mb-4">Water Wastage Analysis</h3>
      <LineChart width={800} height={400} data={chartData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="wastage" stroke="#2563eb" name="Total Wastage" />
        <Line type="monotone" dataKey="evaporation" stroke="#dc2626" name="Evaporation" />
        <Line type="monotone" dataKey="seepage" stroke="#16a34a" name="Seepage" />
      </LineChart>
    </div>
  );
}
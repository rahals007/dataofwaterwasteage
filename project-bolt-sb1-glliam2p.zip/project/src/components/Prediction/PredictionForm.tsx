import React, { useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import type { HistoricalData } from '../../types/database';

interface Props {
  onPredict: (data: {
    temperature: number;
    rainfall: number;
    retentionCapacity: number;
  }) => Promise<number>;
}

export default function PredictionForm({ onPredict }: Props) {
  const [temperature, setTemperature] = useState<number>(25);
  const [rainfall, setRainfall] = useState<number>(100);
  const [retentionCapacity, setRetentionCapacity] = useState<number>(1000);
  const [prediction, setPrediction] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const result = await onPredict({ temperature, rainfall, retentionCapacity });
      setPrediction(result);
    } catch (error) {
      console.error('Prediction failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-lg">
      <h3 className="text-xl font-semibold mb-4">Predict Water Wastage</h3>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Temperature (°C)</label>
          <input
            type="number"
            value={temperature}
            onChange={(e) => setTemperature(Number(e.target.value))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Rainfall (mm)</label>
          <input
            type="number"
            value={rainfall}
            onChange={(e) => setRainfall(Number(e.target.value))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Retention Capacity (m³)</label>
          <input
            type="number"
            value={retentionCapacity}
            onChange={(e) => setRetentionCapacity(Number(e.target.value))}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
        </div>

        <button
          type="submit"
          disabled={loading}
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50"
        >
          {loading ? 'Predicting...' : 'Predict Wastage'}
        </button>
      </form>

      {prediction !== null && (
        <div className="mt-4 p-4 bg-blue-50 rounded-md">
          <h4 className="font-semibold">Predicted Water Wastage:</h4>
          <p className="text-2xl font-bold text-blue-600">{prediction.toFixed(2)} m³</p>
        </div>
      )}
    </div>
  );
}
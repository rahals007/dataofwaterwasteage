import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import type { StructureType } from '../../types/database';

interface Props {
  structure: StructureType;
}

export default function StructureViewer({ structure }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!containerRef.current) return;

    // Setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer();
    
    renderer.setSize(800, 600);
    containerRef.current.appendChild(renderer.domElement);
    
    // Controls
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    
    // Load 3D model
    const loader = new THREE.ObjectLoader();
    loader.load(structure.model_url, (object) => {
      scene.add(object);
    });
    
    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 0.5);
    directionalLight.position.set(0, 1, 0);
    scene.add(directionalLight);
    
    // Position camera
    camera.position.z = 5;
    
    // Animation loop
    function animate() {
      requestAnimationFrame(animate);
      controls.update();
      renderer.render(scene, camera);
    }
    
    animate();
    
    // Cleanup
    return () => {
      containerRef.current?.removeChild(renderer.domElement);
      renderer.dispose();
    };
  }, [structure]);

  return (
    <div className="bg-white p-4 rounded-lg shadow-lg">
      <h3 className="text-xl font-semibold mb-4">Structure Model: {structure.name}</h3>
      <div ref={containerRef} className="w-full h-[600px]" />
      <div className="mt-4 space-y-2">
        <p><strong>Efficiency Rating:</strong> {structure.efficiency_rating}%</p>
        <p><strong>Maintenance:</strong> {structure.maintenance_requirement}</p>
        <p><strong>Capacity Range:</strong> {structure.min_capacity} - {structure.max_capacity} m³</p>
      </div>
    </div>
  );
}
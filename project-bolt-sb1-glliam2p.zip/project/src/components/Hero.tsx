import React from 'react';
import { ArrowDown } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative h-screen flex items-center justify-center text-white">
      <div 
        className="absolute inset-0 bg-cover bg-center z-0"
        style={{
          backgroundImage: 'url("https://images.unsplash.com/photo-1589008647619-5c5288268d76?auto=format&fit=crop&q=80")',
        }}
      >
        <div className="absolute inset-0 bg-black/50" />
      </div>
      
      <div className="z-10 text-center px-4">
        <h1 className="text-5xl md:text-6xl font-bold mb-6">
          Water Wastage Crisis
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
          Understanding the environmental impact of water retention structures
          and working towards sustainable solutions.
        </p>
        <a
          href="#overview"
          className="inline-flex items-center bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition"
        >
          Learn More
          <ArrowDown className="ml-2 h-5 w-5" />
        </a>
      </div>
    </div>
  );
}
import React from 'react';
import { Droplets, Menu } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="bg-blue-600 text-white p-4 fixed w-full top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Droplets className="h-6 w-6" />
          <span className="text-xl font-bold">WaterWatch</span>
        </div>
        <div className="hidden md:flex space-x-6">
          <a href="#overview" className="hover:text-blue-200 transition">Overview</a>
          <a href="#impact" className="hover:text-blue-200 transition">Impact</a>
          <a href="#solutions" className="hover:text-blue-200 transition">Solutions</a>
          <a href="#contact" className="hover:text-blue-200 transition">Contact</a>
        </div>
        <button className="md:hidden">
          <Menu className="h-6 w-6" />
        </button>
      </div>
    </nav>
  );
}
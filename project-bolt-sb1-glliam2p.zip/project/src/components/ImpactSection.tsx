import React from 'react';
import { Droplets, Fish, Trees, AlertTriangle } from 'lucide-react';

const impacts = [
  {
    icon: <Droplets className="h-8 w-8 text-blue-500" />,
    title: "Water Loss",
    description: "Significant water loss through evaporation and seepage from large reservoirs."
  },
  {
    icon: <Fish className="h-8 w-8 text-blue-500" />,
    title: "Ecosystem Damage",
    description: "Disruption of natural water flows affecting aquatic life and biodiversity."
  },
  {
    icon: <Trees className="h-8 w-8 text-blue-500" />,
    title: "Habitat Loss",
    description: "Flooding of natural habitats and displacement of wildlife species."
  },
  {
    icon: <AlertTriangle className="h-8 w-8 text-blue-500" />,
    title: "Climate Impact",
    description: "Increased methane emissions from stagnant water bodies."
  }
];

export default function ImpactSection() {
  return (
    <section id="impact" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">Environmental Impact</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {impacts.map((impact, index) => (
            <div key={index} className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition">
              <div className="mb-4">{impact.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{impact.title}</h3>
              <p className="text-gray-600">{impact.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
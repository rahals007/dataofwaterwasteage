import React from 'react';

export default function SolutionsSection() {
  return (
    <section id="solutions" className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">Sustainable Solutions</h2>
        
        <div className="grid md:grid-cols-2 gap-12">
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1625496253346-cafd58d6ef36?auto=format&fit=crop&q=80"
              alt="Modern water management"
              className="rounded-lg shadow-lg"
            />
          </div>
          
          <div className="space-y-6">
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="text-xl font-semibold mb-2">Modern Monitoring Systems</h3>
              <p className="text-gray-600">Implementation of advanced monitoring technologies to detect and prevent water losses.</p>
            </div>
            
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="text-xl font-semibold mb-2">Efficient Design</h3>
              <p className="text-gray-600">Improved structural designs to minimize evaporation and seepage losses.</p>
            </div>
            
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="text-xl font-semibold mb-2">Alternative Technologies</h3>
              <p className="text-gray-600">Exploration of alternative water storage methods with lower environmental impact.</p>
            </div>
            
            <div className="border-l-4 border-blue-500 pl-4">
              <h3 className="text-xl font-semibold mb-2">Regular Maintenance</h3>
              <p className="text-gray-600">Scheduled maintenance and repairs to prevent structural deterioration and water losses.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
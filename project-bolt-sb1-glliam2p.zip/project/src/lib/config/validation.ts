import { z } from 'zod';

const envSchema = z.object({
  VITE_SUPABASE_URL: z.string().url('Invalid Supabase URL format'),
  VITE_SUPABASE_ANON_KEY: z.string().min(1, 'Supabase anonymous key is required')
});

export function validateConfig() {
  const config = {
    VITE_SUPABASE_URL: import.meta.env.VITE_SUPABASE_URL,
    VITE_SUPABASE_ANON_KEY: import.meta.env.VITE_SUPABASE_ANON_KEY
  };

  try {
    envSchema.parse(config);
  } catch (error) {
    throw new Error(
      'Please configure Supabase:\n' +
      '1. Click the "Connect to Supabase" button in the top right\n' +
      '2. Follow the setup process to create a new project\n' +
      '3. The environment variables will be automatically configured'
    );
  }

  if (
    config.VITE_SUPABASE_URL === 'your_project_url' ||
    config.VITE_SUPABASE_ANON_KEY === 'your_anon_key'
  ) {
    throw new Error(
      'Default Supabase configuration detected.\n' +
      'Please complete the Supabase setup process using the "Connect to Supabase" button.'
    );
  }

  return config;
}
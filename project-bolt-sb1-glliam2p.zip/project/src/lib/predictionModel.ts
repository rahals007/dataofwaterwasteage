import * as tf from '@tensorflow/tfjs';
import type { HistoricalData } from '../types/database';

export async function trainModel(historicalData: HistoricalData[]) {
  const model = tf.sequential();
  
  // Convert data to tensors
  const features = historicalData.map(data => [
    data.temperature,
    data.rainfall,
    data.retention_capacity
  ]);
  
  const labels = historicalData.map(data => data.water_wastage);
  
  const xs = tf.tensor2d(features);
  const ys = tf.tensor1d(labels);
  
  // Define model architecture
  model.add(tf.layers.dense({ units: 10, activation: 'relu', inputShape: [3] }));
  model.add(tf.layers.dense({ units: 1 }));
  
  // Compile and train
  model.compile({ optimizer: 'adam', loss: 'meanSquaredError' });
  await model.fit(xs, ys, { epochs: 100 });
  
  return model;
}

export async function predictWastage(
  model: tf.Sequential,
  temperature: number,
  rainfall: number,
  retentionCapacity: number
) {
  const input = tf.tensor2d([[temperature, rainfall, retentionCapacity]]);
  const prediction = model.predict(input) as tf.Tensor;
  return prediction.dataSync()[0];
}
import { createClient } from '@supabase/supabase-js';
import type { Database } from '../types/database';
import { validateConfig } from './config/validation';

const config = validateConfig();
export const supabase = createClient<Database>(
  config.VITE_SUPABASE_URL,
  config.VITE_SUPABASE_ANON_KEY
);
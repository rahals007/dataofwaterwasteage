import React, { useEffect, useState } from 'react';
import { supabase } from './lib/supabase';
import { trainModel, predictWastage } from './lib/predictionModel';
import type { GeographicalArea, HistoricalData, StructureType } from './types/database';
import WastageChart from './components/DataAnalysis/WastageChart';
import PredictionForm from './components/Prediction/PredictionForm';
import StructureViewer from './components/3DModel/StructureViewer';
import { Droplets } from 'lucide-react';

export default function App() {
  const [historicalData, setHistoricalData] = useState<HistoricalData[]>([]);
  const [structures, setStructures] = useState<StructureType[]>([]);
  const [selectedStructure, setSelectedStructure] = useState<StructureType | null>(null);
  const [model, setModel] = useState<any>(null);

  useEffect(() => {
    async function fetchData() {
      // Fetch historical data
      const { data: histData } = await supabase
        .from('historical_data')
        .select('*')
        .order('date', { ascending: true });
      
      if (histData) {
        setHistoricalData(histData);
        const trainedModel = await trainModel(histData);
        setModel(trainedModel);
      }

      // Fetch structure types
      const { data: structureData } = await supabase
        .from('structure_types')
        .select('*');
      
      if (structureData) {
        setStructures(structureData);
        setSelectedStructure(structureData[0]);
      }
    }

    fetchData();
  }, []);

  const handlePredict = async (data: {
    temperature: number;
    rainfall: number;
    retentionCapacity: number;
  }) => {
    if (!model) throw new Error('Model not ready');
    return predictWastage(
      model,
      data.temperature,
      data.rainfall,
      data.retentionCapacity
    );
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-blue-600 text-white p-4">
        <div className="container mx-auto flex items-center space-x-2">
          <Droplets className="h-6 w-6" />
          <span className="text-xl font-bold">Water Wastage Analysis</span>
        </div>
      </nav>

      <main className="container mx-auto py-8 px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div>
            <WastageChart data={historicalData} />
            <div className="mt-8">
              <PredictionForm onPredict={handlePredict} />
            </div>
          </div>
          
          <div>
            {selectedStructure && <StructureViewer structure={selectedStructure} />}
            <div className="mt-4 bg-white p-4 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold mb-4">Available Structures</h3>
              <div className="grid grid-cols-2 gap-4">
                {structures.map(structure => (
                  <button
                    key={structure.id}
                    onClick={() => setSelectedStructure(structure)}
                    className={`p-4 rounded-lg border transition ${
                      selectedStructure?.id === structure.id
                        ? 'border-blue-500 bg-blue-50'
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <h4 className="font-semibold">{structure.name}</h4>
                    <p className="text-sm text-gray-600">{structure.description}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
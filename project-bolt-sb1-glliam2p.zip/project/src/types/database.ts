export interface GeographicalArea {
  id: string;
  name: string;
  terrain_type: string;
  elevation: number;
  soil_type: string;
  climate_zone: string;
  created_at: string;
}

export interface StructureType {
  id: string;
  name: string;
  description: string;
  min_capacity: number;
  max_capacity: number;
  suitable_terrain: string[];
  suitable_climate: string[];
  efficiency_rating: number;
  maintenance_requirement: string;
  model_url: string;
  created_at: string;
}

export interface HistoricalData {
  id: string;
  geographical_area_id: string;
  date: string;
  temperature: number;
  rainfall: number;
  retention_capacity: number;
  water_wastage: number;
  evaporation_rate: number;
  seepage_rate: number;
  created_at: string;
}